const OPTIONS = {
  method: 'GET'
}
document.getElementById("form").addEventListener("submit", function(event) {
    event.preventDefault(); // Evitar el envío del formulario
    
    // Obtener la palabra clave ingresada por el usuario
    var input = document.getElementById("input").value.toLowerCase();

    // Cargar el archivo JSON
    fetch('https://my-json-server.typicode.com/ribuhub25/menu_Api/comidas/',OPTIONS)
        .then(response => response.json())
        .then(data => {
            // Filtrar las comidas que contienen la palabra clave
            const resultados = data.filter(comida => comida.nombre.toLowerCase().includes(input));
            
            // Mostrar los resultados en la página
            mostrarResultados(resultados);
        })
        .catch(error => console.error('Error al cargar el archivo JSON:', error));
});

// Variable para almacenar las comidas seleccionadas
var comidasSemana = [];

function mostrarResultados(resultados) {
    var resultadosDiv = document.getElementById("results");
    resultadosDiv.innerHTML = ""; // Limpiar resultados anteriores

    if (resultados.length === 0) {
        resultadosDiv.textContent = "No se encontraron resultados.";
    } else {
        var listaResultados = document.createElement("ol");
        resultados.forEach(function(comida) {
            var itemLista = document.createElement("li");

            // Crear un checkbox para cada resultado
            var checkbox = document.createElement("input");
            checkbox.type = "checkbox";
            checkbox.value = comida.nombre; // Establecer el valor del checkbox como el nombre de la comida

            // Crear una etiqueta para el checkbox
            var etiqueta = document.createElement("label");
            etiqueta.textContent = comida.nombre;

            // Agregar el checkbox y la etiqueta al item de la lista
            itemLista.appendChild(checkbox);
            itemLista.appendChild(etiqueta);
            listaResultados.appendChild(itemLista);
            
        });
        resultadosDiv.appendChild(listaResultados);

        // Crear botón "Agregar"
        var botonAgregar = document.createElement("button");
        botonAgregar.className= "centrado"
        botonAgregar.textContent = "Agregar";
        botonAgregar.addEventListener("click", function() {
            // Limpiar lista de comidas de la semana anterior
            //comidasSemana = [];

            // Obtener las comidas seleccionadas
            var checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');
            checkboxes.forEach(function(checkbox) {
                comidasSemana.push(checkbox.value);
            });

            // Mostrar la lista de comidas de la semana
            mostrarComidasSemana();
        });
        resultadosDiv.appendChild(botonAgregar);
    }
}

function mostrarComidasSemana() {
    var listaComidasSemanaDiv = document.getElementById("lista-comidas-semana");
     listaComidasSemanaDiv.innerHTML = ""; // Limpiar lista anterior

    if (comidasSemana.length === 0) {
        listaComidasSemanaDiv.textContent = "No se han agregado comidas para la semana.";
    } else {
        var fechaActual = new Date();
        var anio = fechaActual.getFullYear();
        var mes = fechaActual.getMonth() + 1;
        var dia = fechaActual.getDate();
        // Formatear la fecha como una cadena en el formato deseado (por ejemplo, YYYY-MM-DD)
        var fechaHoy = anio + '-' + (mes < 10 ? '0' + mes : mes) + '-' + (dia < 10 ? '0' + dia : dia);
        var tituloListaSemana = document.createElement("h3");
        tituloListaSemana.textContent=`🍽️ Menú de la Semana🍽️ (${fechaHoy})`
        var listaComidasSemana = document.createElement("ul");
        tituloListaSemana.className="tituloMenu";
        comidasSemana.forEach(function(comida) {
            var itemLista = document.createElement("li");
            itemLista.textContent = comida;
            listaComidasSemana.appendChild(itemLista);
        });
        listaComidasSemanaDiv.appendChild(tituloListaSemana);
        listaComidasSemanaDiv.appendChild(listaComidasSemana);
    }
}





